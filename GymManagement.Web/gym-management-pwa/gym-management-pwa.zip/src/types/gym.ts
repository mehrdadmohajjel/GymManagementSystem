export interface Gym {
  id: number;
  title: string;
  address: string;
  mobile: string;
  isActive: boolean;
}