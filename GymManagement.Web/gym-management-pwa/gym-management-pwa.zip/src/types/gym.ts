export interface Gym {
  id: number;
  name: string;
  code: string;
  address: string;
}