﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GymManagement.Application.Constants
{
    public static class Roles
    {
        public const string SystemAdmin = "SystemAdmin";
        public const string GymAdmin = "GymAdmin";
        public const string Athlete = "Athlete";
    }
}
