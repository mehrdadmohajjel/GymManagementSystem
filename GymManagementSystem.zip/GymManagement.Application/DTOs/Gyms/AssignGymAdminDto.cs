﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GymManagement.Application.DTOs.Gyms
{
    public class AssignGymAdminDto
    {
        public long GymId { get; set; }
        public long UserId { get; set; }
    }

}
