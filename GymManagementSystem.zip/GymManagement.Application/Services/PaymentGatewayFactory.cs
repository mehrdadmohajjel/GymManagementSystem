﻿using GymManagement.Application.Interfaces;
using GymManagement.Domain.enums;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GymManagement.Application.Services
{
    public class PaymentGatewayFactory
    {
        private readonly IServiceProvider _provider;

        public PaymentGatewayFactory(IServiceProvider provider)
        {
            _provider = provider;
        }

        public IPaymentGateway Create(PaymentGatewayType type)
        {
            return type switch
            {
                PaymentGatewayType.ZarinPal => _provider.GetRequiredService<ZarinPalGateway>(),
                PaymentGatewayType.Mellat => _provider.GetRequiredService<MellatGateway>(),
                _ => throw new Exception("درگاه پشتیبانی نمی‌شود")
            };
        }
    }

}
