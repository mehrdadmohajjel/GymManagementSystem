﻿using GymManagement.Application.DTOs.Payments;
using GymManagement.Application.DTOs.Wallet;
using GymManagement.Application.Interfaces;
using GymManagement.Domain.Entities;
using GymManagement.Infrastructure.Data;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Parbad;

namespace GymManagement.Application.Services
{
    public class PaymentService : IPaymentService
    {
        private readonly AppDbContext _context;
        private readonly IHttpContextAccessor _httpContextAccessor;
        private readonly IWalletService _walletService;
        private readonly IPayment _payment;

        public PaymentService(
            AppDbContext context,
            IHttpContextAccessor httpContextAccessor,
            IWalletService walletService,
            IPayment payment)  
        {
            _context = context;
            _httpContextAccessor = httpContextAccessor;
            _walletService = walletService;
            _payment = payment;
        }

        public async Task<string> StartPaymentAsync(long userId, StartPaymentDto dto)
        {
            var user = await _context.Users
                .AsNoTracking()
                .FirstOrDefaultAsync(x => x.Id == userId);

            if (user == null)
                throw new Exception("کاربر یافت نشد");

            var gateway = await _context.PaymentGateways
                .AsNoTracking()
                .FirstOrDefaultAsync(x =>
                    x.GymId == user.GymId &&
                    x.IsActive);

            if (gateway == null)
                throw new Exception("درگاه پرداخت فعالی برای این باشگاه تعریف نشده است");

            var callbackUrl = "https://yourdomain.com/api/payments/verify";

            var result = await _payment
                .UseGateway(gateway.GatewayType.ToString()) // ZarinPal / Mellat
                .RequestAsync(invoice =>
                {
                    invoice
                        .SetAmount(dto.Amount)
                        .SetCallbackUrl(callbackUrl)
                        .SetDescription("شارژ کیف پول");
                });

            if (!result.IsSucceed)
                throw new Exception(result.Message);

            var onlinePayment = new OnlinePayment
            {
                UserId = userId,
                GymId = user.GymId!.Value,
                Amount = dto.Amount,
                GatewayType = gateway.GatewayType,
                Authority = result.Authority,
                RefId = result.RefId,
                IsSuccess = false,
                CreatedAt = DateTime.UtcNow
            };

            _context.OnlinePayments.Add(onlinePayment);
            await _context.SaveChangesAsync();

            return result.GatewayTransporterDescriptor.Url;
        }

        public async Task VerifyAsync()
        {
            var httpContext = _httpContextAccessor.HttpContext
                ?? throw new Exception("HttpContext در دسترس نیست");

            var verifyResult = await _payment.VerifyAsync(httpContext.Request);

            if (!verifyResult.IsSucceed)
                throw new Exception("پرداخت ناموفق بود");

            var payment = await _context.OnlinePayments
                .FirstOrDefaultAsync(x =>
                    !x.IsSuccess &&
                    (x.Authority == verifyResult.Authority ||
                     x.RefId == verifyResult.RefId));

            if (payment == null)
                throw new Exception("پرداخت معتبر یافت نشد");

            payment.IsSuccess = true;
            payment.PaidAt = DateTime.UtcNow;

            await _walletService.ChargeAsync(new ChargeWalletDto
            {
                UserId = payment.UserId,
                Amount = payment.Amount,
                Description = "شارژ کیف پول (پرداخت آنلاین)"
            });

            await _context.SaveChangesAsync();
        }
    }
}
