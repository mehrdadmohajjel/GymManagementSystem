﻿using GymManagement.Application.Interfaces;
using Parbad.Internal;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GymManagement.Application.Services
{
    public class MellatGateway : IPaymentGateway
    {
        private readonly PaymentGatewayClient _client;

        public MellatGateway(PaymentGatewayClient client)
        {
            _client = client;
        }

        public async Task<PaymentRequestResult> RequestAsync(PaymentRequestDto dto)
        {
            var result = await _client.bpPayRequestAsync(
                dto.TerminalId,
                dto.Username,
                dto.Password,
                dto.OrderId,
                dto.Amount,
                DateTime.Now.ToString("yyyyMMdd"),
                DateTime.Now.ToString("HHmmss"),
                "", dto.CallbackUrl, 0);

            var res = result.@return.Split(',');

            if (res[0] != "0")
                throw new Exception("خطای اتصال به بانک ملت");

            return new PaymentRequestResult
            {
                RefId = res[1],
                RedirectUrl = "https://bpm.shaparak.ir/pgwchannel/startpay.mellat"
            };
        }

        public Task<PaymentVerifyResult> VerifyAsync(PaymentVerifyDto dto)
        {
            // bpVerifyRequest + bpSettleRequest
            throw new NotImplementedException();
        }
    }

}
