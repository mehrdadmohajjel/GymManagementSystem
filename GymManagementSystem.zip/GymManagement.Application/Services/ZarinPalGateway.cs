﻿using GymManagement.Application.Interfaces;
using Parbad.Internal;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Json;
using System.Text;
using System.Threading.Tasks;

namespace GymManagement.Application.Services
{
    public class ZarinPalGateway : IPaymentGateway
    {
        private readonly HttpClient _http;

        public ZarinPalGateway(HttpClient http)
        {
            _http = http;
        }

        public async Task<PaymentRequestResult> RequestAsync(PaymentRequestDto dto)
        {
            var response = await _http.PostAsJsonAsync(
                "https://api.zarinpal.com/pg/v4/payment/request.json",
                new
                {
                    merchant_id = dto.MerchantId,
                    amount = dto.Amount,
                    callback_url = dto.CallbackUrl,
                    description = dto.Description
                });

            var result = await response.Content.ReadFromJsonAsync<ZarinPalRequestResponse>();

            if (result.data.code != 100)
                throw new Exception("خطا در اتصال به زرین‌پال");

            return new PaymentRequestResult
            {
                Authority = result.data.authority,
                RedirectUrl = $"https://www.zarinpal.com/pg/StartPay/{result.data.authority}"
            };
        }

        public async Task<PaymentVerifyResult> VerifyAsync(PaymentVerifyDto dto)
        {
            var response = await _http.PostAsJsonAsync(
                "https://api.zarinpal.com/pg/v4/payment/verify.json",
                new
                {
                    merchant_id = dto.MerchantId,
                    amount = dto.Amount,
                    authority = dto.Authority
                });

            var result = await response.Content.ReadFromJsonAsync<ZarinPalVerifyResponse>();

            return new PaymentVerifyResult
            {
                IsSuccess = result.data.code == 100,
                RefId = result.data.ref_id
            };
        }
    }

}
