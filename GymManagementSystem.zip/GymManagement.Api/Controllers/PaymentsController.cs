﻿using GymManagement.Application.Constants;
using GymManagement.Application.DTOs.Payments;
using GymManagement.Application.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

namespace GymManagement.Api.Controllers
{
    [ApiController]
    [Route("api/payments")]
    [Authorize(Roles = Roles.Athlete)]
    public class PaymentsController : ControllerBase
    {
        private readonly IPaymentService _service;

        public PaymentsController(IPaymentService service)
        {
            _service = service;
        }

        [HttpPost("start")]
        public async Task<IActionResult> Start(StartPaymentDto dto)
        {
            var userId = long.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
            var url = await _service.StartPaymentAsync(userId, dto);
            return Ok(new { redirectUrl = url });
        }

        [HttpGet("verify")]
        [AllowAnonymous]
        public async Task<IActionResult> Verify()
        {
            await _service.VerifyAsync();
            return Redirect("/payment-success");
        }
    }

}
