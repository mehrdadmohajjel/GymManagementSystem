export interface LoginRequest {
  nationalCode: string;
  password: string;
}
