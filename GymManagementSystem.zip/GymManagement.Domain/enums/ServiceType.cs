﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GymManagement.Domain.enums
{
    public enum ServiceType
    {
        SessionBased = 1,
        TimeBased = 2
    }
}
