﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GymManagement.Domain.enums
{
    public enum TransactionType
    {
        Charge = 1,
        Consume = 2
    }
}
